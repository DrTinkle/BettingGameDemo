const fs = require('fs');

function loadJsonData(filePath, defaultValue) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (error) {
    console.log(`No existing data for ${filePath}, creating a new one.`);
    return defaultValue;
  }
}

function saveJsonData(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    console.log(`Data saved to ${filePath}`);
  } catch (error) {
    console.error(`Error writing to ${filePath}:`, error);
  }
}

let matchHistory = loadJsonData('data/match_history.json', []);
let teamHistory = loadJsonData('data/team_history.json', {});
let scheduleData = loadJsonData('data/schedule.json', {});

function compareStats(teamA, teamB) {
  let scoreA = 0;
  let scoreB = 0;

  const comparisons = [
    { stat: 'attack', weight: 1 },
    { stat: 'defense', weight: 1 },
    { stat: 'speed', weight: 1 },
    { stat: 'agility', weight: 1 },
    { stat: 'overall', weight: 2 },
    { stat: 'attack', against: 'defense', weight: 1 },
    { stat: 'speed', against: 'agility', weight: 1 },
  ];

  comparisons.forEach(({ stat, against, weight }) => {
    const statA = teamA[stat] || 0; // Default missing stats to 0
    const statB = against ? teamB[against] || 0 : teamB[stat] || 0;

    if (statA > statB) {
      scoreA += weight * (statA - statB);
    } else if (statB > statA) {
      scoreB += weight * (statB - statA);
    }
  });

  return { scoreA, scoreB };
}

function generateScore(sport, scoreA, scoreB) {
  let scoreTeamA = 0;
  let scoreTeamB = 0;

  const adjustForScoreDifference = (scoreA, scoreB, averagePoints, maxPoints) => {
    if (scoreA === 0 && scoreB === 0) {
      // Handle case where both teams have zero score to avoid NaN
      scoreTeamA = Math.round(Math.random() * averagePoints);
      scoreTeamB = Math.round(Math.random() * averagePoints);
    } else {
      const totalScore = scoreA + scoreB;
      const randomness = Math.random() * (maxPoints - averagePoints) * 0.5;

      scoreTeamA = Math.round((scoreA / totalScore) * averagePoints + randomness);
      scoreTeamB = Math.round((scoreB / totalScore) * averagePoints + randomness);
    }
  };

  switch (sport) {
    case 'hockey': {
      adjustForScoreDifference(scoreA, scoreB, 3.1, 10);
      break;
    }
    case 'soccer': {
      adjustForScoreDifference(scoreA, scoreB, 2.7, 7);
      break;
    }
    case 'boxing': {
      const rounds = 3;
      for (let i = 0; i < rounds; i++) {
        const roundScoreA = Math.random() * (scoreA + 1); // Add 1 to avoid multiplying by 0
        const roundScoreB = Math.random() * (scoreB + 1);

        if (roundScoreA > roundScoreB) {
          scoreTeamA += 10;
          scoreTeamB += 9;
        } else if (roundScoreB > roundScoreA) {
          scoreTeamA += 9;
          scoreTeamB += 10;
        } else {
          scoreTeamA += 10;
          scoreTeamB += 10;
        }
      }
      break;
    }

    default: {
      console.error(`Unhandled sport type: ${sport}`);
      return { scoreTeamA: 0, scoreTeamB: 0 }; // Default to 0-0 if sport type is unknown
    }
  }

  return { scoreTeamA, scoreTeamB };
}

function randomizePastMatchResults(scheduleData) {
  Object.entries(scheduleData).forEach(([sport, sportData]) => {
    // Use Object.entries to get the sport key
    if (sportData.season && sportData.season.pastMatchups) {
      sportData.season.pastMatchups.forEach((match) => {
        const teamA = teamHistory[match.teamA] || {};
        const teamB = teamHistory[match.teamB] || {};

        const { scoreA, scoreB } = compareStats(teamA, teamB);
        const { scoreTeamA, scoreTeamB } = generateScore(sport, scoreA, scoreB); // Pass sport here

        match.result = `${match.teamA} ${scoreTeamA} - ${scoreTeamB} ${match.teamB}`;

        const matchId = `match_${matchHistory.length + 1}`;

        matchHistory.push({
          matchId,
          sport, // Include sport in the history
          teamA: match.teamA,
          teamB: match.teamB,
          scoreTeamA,
          scoreTeamB,
          winner: scoreTeamA > scoreTeamB ? match.teamA : scoreTeamB > scoreTeamA ? match.teamB : 'draw',
        });

        if (!teamHistory[match.teamA]) {
          teamHistory[match.teamA] = { matches: [] };
        }
        if (!teamHistory[match.teamB]) {
          teamHistory[match.teamB] = { matches: [] };
        }
        teamHistory[match.teamA].matches.push(matchId);
        teamHistory[match.teamB].matches.push(matchId);
      });
    }
  });

  saveJsonData('data/match_history.json', matchHistory);
  saveJsonData('data/team_history.json', teamHistory);
}

function randomizeNextMatchResult(scheduleData) {
  Object.values(scheduleData).forEach((sportData) => {
    const sport = sportData.sport;
    if (sportData.season && sportData.season.matchups) {
      const nextMatch = sportData.season.matchups.find((match) => match.result === null);

      if (nextMatch) {
        const teamA = teamHistory[nextMatch.teamA] || {};
        const teamB = teamHistory[nextMatch.teamB] || {};

        const { scoreA, scoreB } = compareStats(teamA, teamB);
        const { scoreTeamA, scoreTeamB } = generateScore(sport, scoreA, scoreB);

        nextMatch.result = `${nextMatch.teamA} ${scoreTeamA} - ${scoreTeamB} ${nextMatch.teamB}`;

        const matchId = `match_${matchHistory.length + 1}`;

        matchHistory.push({
          matchId,
          sport,
          teamA: nextMatch.teamA,
          teamB: nextMatch.teamB,
          scoreTeamA,
          scoreTeamB,
          winner: scoreTeamA > scoreTeamB ? nextMatch.teamA : scoreTeamB > scoreTeamA ? nextMatch.teamB : 'draw',
        });

        if (!teamHistory[nextMatch.teamA]) {
          teamHistory[nextMatch.teamA] = { matches: [] };
        }
        if (!teamHistory[nextMatch.teamB]) {
          teamHistory[nextMatch.teamB] = { matches: [] };
        }
        teamHistory[nextMatch.teamA].matches.push(matchId);
        teamHistory[nextMatch.teamB].matches.push(matchId);
      }
    }
  });

  saveJsonData('data/match_history.json', matchHistory);
  saveJsonData('data/team_history.json', teamHistory);
}

module.exports = { compareStats, generateScore, randomizePastMatchResults, randomizeNextMatchResult };

if (require.main === module) {
  randomizeNextMatchResult(scheduleData);
  console.log('Next match result has been randomized and updated. Match and team histories saved.');
}

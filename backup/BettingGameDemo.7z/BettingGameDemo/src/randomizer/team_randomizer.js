const fs = require('fs');

const teamsData = JSON.parse(fs.readFileSync('data/teams.json', 'utf8'));

function randomizeStats(team) {
  if (!team.randomized) {
    team.speed = Math.floor(Math.random() * 100) + 1;
    team.agility = Math.floor(Math.random() * 100) + 1;
    team.attack = Math.floor(Math.random() * 100) + 1;
    team.defense = Math.floor(Math.random() * 100) + 1;
    team.overall = Math.round((team.speed + team.agility + team.attack + team.defense) / 4);
    team.randomized = true;
  }
}

teamsData.forEach((sport) => {
  sport.teams.forEach((team) => {
    randomizeStats(team);
  });
});

fs.writeFileSync('data/teams.json', JSON.stringify(teamsData, null, 2));

console.log('Teams stats have been randomized and updated.');

// console.log(JSON.stringify(teamsData, null, 2));

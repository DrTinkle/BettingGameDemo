import { compareStats, generateScore } from './simulator/match_result_randomizer.js';

// Load match history and schedule data
async function loadMatchHistory() {
  try {
    const response = await fetch('../data/match_history.json');
    const matchHistory = await response.json();
    return matchHistory;
  } catch (error) {
    console.error('Error loading match history:', error);
  }
}

async function loadScheduleData() {
  try {
    const response = await fetch('../data/schedule.json');
    const scheduleData = await response.json();
    return scheduleData;
  } catch (error) {
    console.error('Error loading schedule data:', error);
  }
}

// Load team data from teams.json
async function loadTeamsData() {
  try {
    const response = await fetch('../data/teams.json');
    const teamsData = await response.json();
    return teamsData;
  } catch (error) {
    console.error('Error loading teams data:', error);
  }
}

// Fetch team stats based on sport and team name
async function fetchTeamStats(teamName, sport) {
  const teamsData = await loadTeamsData();

  // Find the correct sport
  const sportObject = teamsData.find((entry) => entry.sport === sport);

  if (!sportObject) {
    console.error(`Sport ${sport} not found in teams.json.`);
    return null;
  }

  // Find the team within that sport
  const team = sportObject.teams.find((team) => team.name === teamName);

  if (!team) {
    console.error(`Team ${teamName} not found in ${sport}.`);
    return null;
  }

  // Return the team stats
  return team;
}

// Use the comprehensive score generation system from match_result_randomizer.js
async function generateMatchScore(sport, teamA, teamB) {
  const { compareStats, generateScore } = await import('./src/simulator/match_result_randomizer.js');

  // Compare the team stats and generate scores based on the sport
  const { scoreA, scoreB } = compareStats(teamA, teamB);
  const { scoreTeamA, scoreTeamB } = generateScore(sport, scoreA, scoreB);

  return { scoreTeamA, scoreTeamB };
}

// Handle the next match when "Next Day" is clicked
async function handleNextMatch() {
  const scheduleData = await loadScheduleData();
  const matchHistory = await loadMatchHistory();

  // Loop through each sport and find the next available match
  Object.keys(scheduleData).forEach(async (sport) => {
    const sportSeason = scheduleData[sport]?.season;
    const matchups = sportSeason.matchups;

    // Find the first matchup without a result
    const nextMatch = matchups.find((match) => match.result === null);

    if (nextMatch) {
      // Fetch team stats
      const teamA = await fetchTeamStats(nextMatch.teamA, sport);
      const teamB = await fetchTeamStats(nextMatch.teamB, sport);

      if (!teamA || !teamB) {
        console.error('Error fetching team stats.');
        return;
      }

      // Generate the score for the next match
      const { scoreTeamA, scoreTeamB } = await generateMatchScore(sport, teamA, teamB);
      nextMatch.result = `${nextMatch.teamA} ${scoreTeamA} - ${scoreTeamB} ${nextMatch.teamB}`;

      // Add the match to the match history
      matchHistory.push({
        teamA: nextMatch.teamA,
        teamB: nextMatch.teamB,
        scoreTeamA,
        scoreTeamB,
        sport: sport,
        order: nextMatch.order,
        result: nextMatch.result,
      });

      console.log(`Match added to history: ${nextMatch.teamA} ${scoreTeamA} vs ${nextMatch.teamB} ${scoreTeamB}`);

      // Update the display for matchups
      updateUpcomingMatchups();
    }
  });

  // Here, you would save the updated matchHistory and scheduleData to files (for persistence)
  // But for now, we're just logging them for demonstration purposes.
}

// Function to update the upcoming matchups display
function updateUpcomingMatchups() {
  const matchupsList = document.getElementById('upcomingMatchupsList');
  matchupsList.innerHTML = ''; // Clear existing matchups

  // Load and display the next matchups again
  listNextMatchups(); // Call the function from next_matchups.js to refresh the display
}

// Event listener for the "Next Day" button
document.addEventListener('DOMContentLoaded', function () {
  const nextDayButton = document.getElementById('nextDay');
  if (nextDayButton) {
    nextDayButton.addEventListener('click', function () {
      handleNextMatch(); // Handle the next match when "Next Day" is clicked
    });
  }
});

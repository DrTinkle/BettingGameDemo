const express = require('express');
const path = require('path');
const app = express();

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve data files from the 'data' directory
app.use('/data', express.static(path.join(__dirname, 'data')));

// Serve files from the 'src/simulator' directory
app.use('/src/simulator', express.static(path.join(__dirname, 'src/simulator')));

// Route for the main page (index.html)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

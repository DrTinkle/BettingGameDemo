const express = require('express');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process'); // To run the entire scheduler.js script
const { generateTournamentSchedule } = require('./public/src/scheduler/scheduler'); // Updated path for the scheduler
const { calculateOddsForMatchup } = require('./public/src/calculators/odds_calculator.js'); // Use the correct path for odds_calculator
const app = express();

app.use(express.json({ limit: '10mb' })); // To parse JSON request bodies

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve data files from the 'data' directory
app.use('/data', express.static(path.join(__dirname, 'data')));

// Serve simulator files (updated path)
app.use('/src/simulator', express.static(path.join(__dirname, 'public/src/simulator')));

// Route for the main page (index.html)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API route to load the current schedule (if it exists)
app.get('/api/load-schedule', (req, res) => {
  const scheduleFilePath = path.join(__dirname, 'data/schedule.json');

  if (fs.existsSync(scheduleFilePath)) {
    const scheduleData = JSON.parse(fs.readFileSync(scheduleFilePath));
    res.json(scheduleData);
  } else {
    res.status(404).json({ error: 'Schedule not found' });
  }
});

// API route to update the match history
app.post('/api/update-match-history', (req, res) => {
  const { matchId, result } = req.body; // Expecting matchId and result in the request body

  const historyFilePath = path.join(__dirname, 'data/match_history.json');
  let matchHistory = [];

  if (fs.existsSync(historyFilePath)) {
    matchHistory = JSON.parse(fs.readFileSync(historyFilePath));
  }

  // Find the match and update its result, or add a new entry
  const match = matchHistory.find((m) => m.id === matchId);
  if (match) {
    match.result = result;
  } else {
    matchHistory.push({ id: matchId, result });
  }

  // Save updated match history
  fs.writeFileSync(historyFilePath, JSON.stringify(matchHistory, null, 2));

  res.json({ success: true, matchHistory });
});

// API route to run the entire scheduler.js script
app.get('/api/run-scheduler', (req, res) => {
  // Run the entire scheduler.js script
  exec('node ./public/src/scheduler/scheduler.js', (error, stdout, stderr) => {
    // Updated path
    if (error) {
      console.error(`Error executing scheduler: ${error}`);
      return res.status(500).json({ error: 'Error running scheduler' });
    }
    if (stderr) {
      console.error(`Scheduler stderr: ${stderr}`);
    }

    console.log(`Scheduler output: ${stdout}`);
    res.json({ message: 'Scheduler ran successfully', output: stdout });
  });
});

// Save match history data
app.post('/api/save-match-history', (req, res) => {
  const matchHistory = req.body; // Expect the match history data in the request body
  const matchHistoryPath = path.join(__dirname, 'data/match_history.json');
  fs.writeFileSync(matchHistoryPath, JSON.stringify(matchHistory, null, 2));
  res.json({ success: true });
});

// Save team history data
app.post('/api/save-team-history', (req, res) => {
  const teamHistory = req.body;
  const teamHistoryPath = path.join(__dirname, 'data/team_history.json');
  fs.writeFileSync(teamHistoryPath, JSON.stringify(teamHistory, null, 2));
  res.json({ success: true });
});

// Save schedule data
app.post('/api/save-schedule', (req, res) => {
  const schedule = req.body;
  const schedulePath = path.join(__dirname, 'data/schedule.json');
  fs.writeFileSync(schedulePath, JSON.stringify(schedule, null, 2));
  res.json({ success: true });
});

// API route to calculate odds for the next matchup
app.get('/api/calculate-odds', (req, res) => {
  const { teamA, teamB } = req.query;

  if (!teamA || !teamB) {
    return res.status(400).json({ error: 'Missing teamA or teamB in query' });
  }

  try {
    // Call the odds calculation function
    const odds = calculateOddsForMatchup(teamA, teamB);
    res.json(odds); // Send the calculated odds as JSON
  } catch (error) {
    console.error('Error calculating odds:', error);
    res.status(500).json({ error: 'Failed to calculate odds' });
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

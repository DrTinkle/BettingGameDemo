// Load the schedule data (next matchups) from schedule.json
async function loadScheduleData() {
  try {
    const response = await fetch('../data/schedule.json');
    const scheduleData = await response.json();
    return scheduleData;
  } catch (error) {
    console.error('Error loading schedule data:', error);
  }
}

// Function to list the next matchups for each sport
async function listNextMatchups() {
  const scheduleData = await loadScheduleData();

  const matchupsList = document.getElementById('upcomingMatchupsList');
  matchupsList.innerHTML = ''; // Clear any existing content

  // Loop through each sport in the schedule
  Object.keys(scheduleData).forEach((sport) => {
    const sportSeason = scheduleData[sport]?.season;

    if (!sportSeason || !sportSeason.matchups || sportSeason.matchups.length === 0) {
      console.error(`No matchups found for ${sport}`);
      return;
      a;
    }

    // Create a subtitle for the sport
    const sportTitle = document.createElement('h3');
    sportTitle.textContent = `${sport.charAt(0).toUpperCase() + sport.slice(1)} Upcoming Match`;
    matchupsList.appendChild(sportTitle);

    // Get the first upcoming matchup for the sport
    const firstMatch = sportSeason.matchups[0];
    const listItem = document.createElement('li');
    listItem.textContent = `${firstMatch.teamA} vs ${firstMatch.teamB}`;
    matchupsList.appendChild(listItem);
  });
}

// Initial load for all sports' next matchups
document.addEventListener('DOMContentLoaded', function () {
  listNextMatchups(); // Load matchups for all sports on page load
});

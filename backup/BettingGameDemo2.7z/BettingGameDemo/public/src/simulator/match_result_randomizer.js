const fs = require('fs');
const path = require('path');
const rootPath = path.join(__dirname, '../../../');

// Adjust file paths to point to the /data directory
function loadJsonData(filePath, defaultValue) {
  const fullPath = path.join(rootPath, '/data', filePath);
  try {
    return JSON.parse(fs.readFileSync(fullPath, 'utf8'));
  } catch (error) {
    console.log(`No existing data for ${filePath}, creating a new one.`);
    return defaultValue;
  }
}

function saveJsonData(filePath, data) {
  const fullPath = path.join(rootPath, '/data', filePath);
  try {
    fs.writeFileSync(fullPath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error(`Error writing to ${filePath}:`, error);
  }
}

// Loading data with corrected paths
let matchHistory = loadJsonData('match_history.json', []);
let teamHistory = loadJsonData('team_history.json', {});

// The rest of the logic stays the same
function compareStats(teamA, teamB) {
  let scoreA = 0;
  let scoreB = 0;

  const comparisons = [
    { stat: 'attack', weight: 1 },
    { stat: 'defense', weight: 1 },
    { stat: 'speed', weight: 1 },
    { stat: 'agility', weight: 1 },
    { stat: 'overall', weight: 1 },
    { stat: 'attack', against: 'defense', weight: 1 },
    { stat: 'speed', against: 'agility', weight: 1 },
  ];

  comparisons.forEach(({ stat, against, weight }) => {
    const statA = teamA[stat] || 0; // Default missing stats to 0
    const statB = against ? teamB[against] || 0 : teamB[stat] || 0;

    if (statA > statB) {
      scoreA += weight * (statA - statB);
    } else if (statB > statA) {
      scoreB += weight * (statB - statA);
    }
  });

  return { scoreA, scoreB };
}

function generateScore(sport, scoreA, scoreB) {
  let scoreTeamA = 0;
  let scoreTeamB = 0;

  const adjustForScoreDifference = (scoreA, scoreB, averagePoints, maxPoints) => {
    if (scoreA === 0 && scoreB === 0) {
      // Handle case where both teams have zero score to avoid NaN
      scoreTeamA = Math.round(Math.random() * averagePoints);
      scoreTeamB = Math.round(Math.random() * averagePoints);
    } else {
      const totalScore = scoreA + scoreB;
      const randomness = Math.random() * (maxPoints - averagePoints) * 0.5;

      scoreTeamA = Math.round((scoreA / totalScore) * averagePoints + randomness);
      scoreTeamB = Math.round((scoreB / totalScore) * averagePoints + randomness);
    }
  };

  const generateScoreBoxing = (scoreA, scoreB) => {
    const rounds = 4;
    const knockoutThreshold = 20; // Knockout happens if adjusted score difference exceeds this threshold
    const diceRollMax = 20; // Max value for dice rolls per round

    let knockoutOccurred = false;

    // Loop through each round
    for (let i = 0; i < rounds; i++) {
      // Generate random dice rolls for each fighter
      const roundRollA = Math.random() * diceRollMax; // Random roll for Team A
      const roundRollB = Math.random() * diceRollMax; // Random roll for Team B

      // Adjust the dice roll by the stat comparison score
      const adjustedScoreA = roundRollA + scoreA / 10;
      const adjustedScoreB = roundRollB + scoreB / 10;

      // Check for knockout
      const scoreDifference = Math.abs(adjustedScoreA - adjustedScoreB);
      if (scoreDifference > knockoutThreshold) {
        knockoutOccurred = true;
        if (adjustedScoreA > adjustedScoreB) {
          scoreTeamA += 10; // Team A wins by knockout
          scoreTeamB += 7; // Knocked out Team B gets a lower score
        } else {
          scoreTeamA += 7; // Knocked out Team A gets a lower score
          scoreTeamB += 10; // Team B wins by knockout
        }
        break; // End the fight due to knockout
      }

      // Regular round scoring based on the adjusted score
      if (adjustedScoreA > adjustedScoreB) {
        scoreTeamA += 10;
        scoreTeamB += 8 + Math.floor(Math.random() * 2); // Losing fighter gets 8 or 9
      } else if (adjustedScoreB > adjustedScoreA) {
        scoreTeamA += 8 + Math.floor(Math.random() * 2); // Losing fighter gets 8 or 9
        scoreTeamB += 10;
      } else {
        // If it's a tie in the round
        scoreTeamA += 10;
        scoreTeamB += 10;
      }
    }
  };

  switch (sport) {
    case 'hockey': {
      adjustForScoreDifference(scoreA, scoreB, 3.1, 10);
      break;
    }
    case 'soccer': {
      adjustForScoreDifference(scoreA, scoreB, 2.7, 7);
      break;
    }
    case 'boxing': {
      generateScoreBoxing(scoreA, scoreB);
      break;
    }

    default: {
      console.error(`Unhandled sport type: ${sport}`);
      return { scoreTeamA: 0, scoreTeamB: 0 }; // Default to 0-0 if sport type is unknown
    }
  }

  return { scoreTeamA, scoreTeamB };
}

function randomizePastMatchResults(scheduleData) {
  clearHistories();

  Object.entries(scheduleData).forEach(([sport, sportData]) => {
    // Use Object.entries to get the sport key
    if (sportData.season && sportData.season.pastMatchups) {
      sportData.season.pastMatchups.forEach((match) => {
        const teamA = teamHistory[match.teamA] || {};
        const teamB = teamHistory[match.teamB] || {};

        const { scoreA, scoreB } = compareStats(teamA, teamB);
        const { scoreTeamA, scoreTeamB } = generateScore(sport, scoreA, scoreB); // Pass sport here

        match.result = `${match.teamA} ${scoreTeamA} - ${scoreTeamB} ${match.teamB}`;

        const matchId = `match_${matchHistory.length + 1}`;

        matchHistory.push({
          matchId,
          sport, // Include sport in the history
          teamA: match.teamA,
          teamB: match.teamB,
          scoreTeamA,
          scoreTeamB,
          winner: scoreTeamA > scoreTeamB ? match.teamA : scoreTeamB > scoreTeamA ? match.teamB : 'draw',
        });

        if (!teamHistory[match.teamA]) {
          teamHistory[match.teamA] = { matches: [] };
        }
        if (!teamHistory[match.teamB]) {
          teamHistory[match.teamB] = { matches: [] };
        }
        teamHistory[match.teamA].matches.push(matchId);
        teamHistory[match.teamB].matches.push(matchId);
      });
    }
  });

  saveJsonData('match_history.json', matchHistory);
  saveJsonData('team_history.json', teamHistory);
  console.log('Team and match history saved');
}

function clearHistories() {
  // Clear match history
  matchHistory = [];
  saveJsonData('match_history.json', matchHistory);

  // Clear team history
  teamHistory = {};
  saveJsonData('team_history.json', teamHistory);
  console.log('Team and match history cleared.');
}

module.exports = { compareStats, generateScore, randomizePastMatchResults };

// Function to load JSON data
async function loadJsonData(fileName) {
  const filePath = `../../data/${fileName}.json`; // Construct the file path
  try {
    const response = await fetch(filePath);
    return await response.json();
  } catch (error) {
    console.error(`Error loading data from ${filePath}:`, error);
    return null;
  }
}

// Function to save JSON data
async function saveJsonData(endpoint, data) {
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error('Failed to save data');
    }

    return await response.json();
  } catch (error) {
    console.error(`Error saving data to ${endpoint}:`, error);
  }
}

// Compare team stats using the same logic as match_result_randomizer.js
function compareStats(teamA, teamB) {
  let scoreA = 0;
  let scoreB = 0;

  const comparisons = [
    { stat: 'attack', weight: 1 },
    { stat: 'defense', weight: 1 },
    { stat: 'speed', weight: 1 },
    { stat: 'agility', weight: 1 },
    { stat: 'overall', weight: 1 },
    { stat: 'attack', against: 'defense', weight: 1 },
    { stat: 'speed', against: 'agility', weight: 1 },
  ];

  comparisons.forEach(({ stat, against, weight }) => {
    const statA = teamA[stat] || 0;
    const statB = against ? teamB[against] || 0 : teamB[stat] || 0;

    if (statA > statB) {
      scoreA += weight * (statA - statB);
    } else if (statB > statA) {
      scoreB += weight * (statB - statA);
    }
  });

  console.log(`Stat comparisons: ${scoreA} vs ${scoreB}`);

  return { scoreA, scoreB };
}

// Generate match scores based on sport using the original logic from match_result_randomizer.js
function generateScore(sport, scoreA, scoreB) {
  let scoreTeamA = 0;
  let scoreTeamB = 0;

  const adjustForScoreDifference = (scoreA, scoreB, averagePoints, maxPoints) => {
    if (scoreA === 0 && scoreB === 0) {
      // Handle case where both teams have zero score to avoid NaN
      scoreTeamA = Math.round(Math.random() * averagePoints);
      scoreTeamB = Math.round(Math.random() * averagePoints);
    } else {
      const totalScore = scoreA + scoreB;
      const randomness = Math.random() * (maxPoints - averagePoints) * 0.5;

      scoreTeamA = Math.round((scoreA / totalScore) * averagePoints + randomness);
      scoreTeamB = Math.round((scoreB / totalScore) * averagePoints + randomness);
    }
  };

  const generateScoreBoxing = (scoreA, scoreB) => {
    const rounds = 4;
    const knockoutThreshold = 20; // Knockout happens if adjusted score difference exceeds this threshold
    const diceRollMax = 20; // Max value for dice rolls per round

    let knockoutOccurred = false;

    // Loop through each round
    for (let i = 0; i < rounds; i++) {
      // Generate random dice rolls for each fighter
      const roundRollA = Math.random() * diceRollMax; // Random roll for Team A
      const roundRollB = Math.random() * diceRollMax; // Random roll for Team B

      // console.log('Rolls: ' + roundRollA, roundRollB);

      // Adjust the dice roll by the stat comparison score
      const adjustedScoreA = roundRollA + scoreA / 10;
      const adjustedScoreB = roundRollB + scoreB / 10;

      // console.log('Adjusted scores: ' + adjustedScoreA, adjustedScoreB);

      // Check for knockout
      const scoreDifference = Math.abs(adjustedScoreA - adjustedScoreB);
      if (scoreDifference > knockoutThreshold) {
        knockoutOccurred = true;
        if (adjustedScoreA > adjustedScoreB) {
          scoreTeamA += 10; // Team A wins by knockout
          scoreTeamB += 7; // Knocked out Team B gets a lower score
        } else {
          scoreTeamA += 7; // Knocked out Team A gets a lower score
          scoreTeamB += 10; // Team B wins by knockout
        }
        break; // End the fight due to knockout
      }

      // Regular round scoring based on the adjusted score
      if (adjustedScoreA > adjustedScoreB) {
        scoreTeamA += 10;
        scoreTeamB += 8 + Math.floor(Math.random() * 2); // Losing fighter gets 8 or 9
      } else if (adjustedScoreB > adjustedScoreA) {
        scoreTeamA += 8 + Math.floor(Math.random() * 2); // Losing fighter gets 8 or 9
        scoreTeamB += 10;
      } else {
        // If it's a tie in the round
        scoreTeamA += 10;
        scoreTeamB += 10;
      }
    }
  };

  switch (sport) {
    case 'hockey': {
      adjustForScoreDifference(scoreA, scoreB, 3.1, 10);
      break;
    }
    case 'soccer': {
      adjustForScoreDifference(scoreA, scoreB, 2.7, 7);
      break;
    }
    case 'boxing': {
      generateScoreBoxing(scoreA, scoreB);
      break;
    }

    default: {
      console.error(`Unhandled sport type: ${sport}`);
      return { scoreTeamA: 0, scoreTeamB: 0 }; // Default to 0-0 if sport type is unknown
    }
  }

  return { scoreTeamA, scoreTeamB };
}

// Main handler for the next match
async function handleNextMatch() {
  const scheduleData = await loadJsonData('schedule');
  const matchHistory = await loadJsonData('match_history');
  const teamHistory = await loadJsonData('team_history');
  const teamsData = await loadJsonData('teams');

  // Find the next match to be played
  Object.keys(scheduleData).forEach(async (sport) => {
    const season = scheduleData[sport]?.season;
    const nextMatch = season.matchups.find((match) => !match.result);

    if (nextMatch) {
      // Fetch team stats based on the sport
      const sportTeams = teamsData.find((entry) => entry.sport === sport)?.teams || [];
      const teamAStats = sportTeams.find((team) => team.name === nextMatch.teamA);
      const teamBStats = sportTeams.find((team) => team.name === nextMatch.teamB);

      if (!teamAStats || !teamBStats) {
        console.error(`Error fetching stats for ${nextMatch.teamA} or ${nextMatch.teamB}.`);
        return;
      }

      // Compare team stats and generate the score
      const { scoreA, scoreB } = compareStats(teamAStats, teamBStats);
      const { scoreTeamA, scoreTeamB } = generateScore(sport, scoreA, scoreB);
      nextMatch.result = `${nextMatch.teamA} ${scoreTeamA} - ${scoreTeamB} ${nextMatch.teamB}`;

      // Determine the winner
      const winner = scoreTeamA === scoreTeamB ? 'draw' : scoreTeamA > scoreTeamB ? nextMatch.teamA : nextMatch.teamB;

      // Generate unique matchId based on matchHistory length
      const matchId = `match_${matchHistory.length + 1}`;

      // Update match history and team history
      matchHistory.push({
        matchId: matchId, // Unique match ID
        sport: sport, // Ensure sport is included
        teamA: nextMatch.teamA,
        teamB: nextMatch.teamB,
        scoreTeamA,
        scoreTeamB,
        winner: winner, // Ensure winner is included
      });

      if (!teamHistory[nextMatch.teamA]) teamHistory[nextMatch.teamA] = { matches: [] };
      if (!teamHistory[nextMatch.teamB]) teamHistory[nextMatch.teamB] = { matches: [] };

      teamHistory[nextMatch.teamA].matches.push(matchId);
      teamHistory[nextMatch.teamB].matches.push(matchId);

      // Move the match from matchups to pastMatchups in schedule
      season.pastMatchups.push(nextMatch);
      season.matchups = season.matchups.filter((m) => m !== nextMatch);

      // Add more details to nextMatch before passing it to updateMatchResultsHistory
      nextMatch.sport = sport;
      nextMatch.scoreTeamA = scoreTeamA;
      nextMatch.scoreTeamB = scoreTeamB;
      nextMatch.winner = winner;

      console.log(nextMatch);
      // Update the UI and save data
      updateMatchResultsHistory(nextMatch);
      await saveJsonData('/api/save-match-history', matchHistory);
      await saveJsonData('/api/save-team-history', teamHistory);
      await saveJsonData('/api/save-schedule', scheduleData);

      listNextMatchups();
    }
  });
}

// Function to update the match results history for all matches
function updateMatchResultsHistory(match) {
  // Get the results container element from the DOM
  const resultsContainer = document.getElementById('resultsContainer');

  // Check if there's already a list for this sport, if not, create it
  let sportList = document.getElementById(`${match.sport}-results-list`);

  if (!sportList) {
    // Create a new heading and list for the sport
    const sportHeading = document.createElement('h3');
    sportHeading.textContent = `${match.sport.charAt(0).toUpperCase() + match.sport.slice(1)} Match Results`;

    sportList = document.createElement('ul');
    sportList.id = `${match.sport}-results-list`;

    // Append the new heading and list to the results container
    resultsContainer.appendChild(sportHeading);
    resultsContainer.appendChild(sportList);
  }

  // Create a new list item for the match result
  const listItem = document.createElement('li');
  listItem.textContent = `${match.teamA} ${match.scoreTeamA} - ${match.scoreTeamB} ${match.teamB} (Winner: ${match.winner})`;

  // Append the new match result to the sport-specific list
  sportList.appendChild(listItem);
}

// Initialize the "Next Day" button
function setupNextDayButton() {
  document.getElementById('nextDay').addEventListener('click', handleNextMatch);
}
